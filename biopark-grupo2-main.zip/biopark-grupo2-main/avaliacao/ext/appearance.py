from flask_bootstrap import Bootstrap


def init_app(app):
    Bootstrap(app)
